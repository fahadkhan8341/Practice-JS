var app = new Vue({
  el: "#app",
  data() {
    return { list: undefined };
  },
  methods: {
    playVideo() {
      document.querySelector(".video-container").classList.add("active");
    },
    closeVideo() {
      document.querySelector(".video-container").classList.remove("active");
    },
  },
  mounted() {
    axios
      .get("static/thumbnails.json")
      .then((res) => res.data)
      .then((json) => {
        this.list = json;
        console.log(json);
      });
  },
});

